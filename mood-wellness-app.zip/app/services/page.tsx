"use client"

import { useEffect, useState } from "react"
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, LineChart, Line } from "recharts"
import { TrendingUp, TrendingDown } from "lucide-react"

const monthlyData = [
  { month: "Jan", happy: 12, calm: 8, neutral: 6, anxious: 4, sad: 2, stressed: 3 },
  { month: "Feb", happy: 15, calm: 10, neutral: 5, anxious: 3, sad: 1, stressed: 2 },
  { month: "Mar", happy: 18, calm: 12, neutral: 4, anxious: 2, sad: 1, stressed: 1 },
  { month: "Apr", happy: 20, calm: 14, neutral: 3, anxious: 2, sad: 0, stressed: 1 },
  { month: "May", happy: 22, calm: 16, neutral: 2, anxious: 1, sad: 0, stressed: 1 },
  { month: "Jun", happy: 25, calm: 18, neutral: 2, anxious: 1, sad: 0, stressed: 0 },
]

const weeklyTrend = [
  { day: "Mon", mood: 7 },
  { day: "Tue", mood: 8 },
  { day: "Wed", mood: 6 },
  { day: "Thu", mood: 9 },
  { day: "Fri", mood: 8 },
  { day: "Sat", mood: 9 },
  { day: "Sun", mood: 7 },
]

const stressData = [
  { day: "Mon", level: 6 },
  { day: "Tue", level: 4 },
  { day: "Wed", level: 5 },
  { day: "Thu", level: 3 },
  { day: "Fri", level: 2 },
  { day: "Sat", level: 1 },
  { day: "Sun", level: 2 },
]

export default function ServicesPage() {
  const [currentMood, setCurrentMood] = useState<string | null>(null)

  useEffect(() => {
    const mood = localStorage.getItem("currentMood")
    setCurrentMood(mood)
  }, [])

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Your Personalized Wellness Report</h1>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {/* Mood Trends */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Mood Trends</h3>
              <TrendingUp className="w-5 h-5 text-green-600" />
            </div>
            <div className="flex items-baseline space-x-2 mb-4">
              <span className="text-3xl font-bold text-gray-900">+5%</span>
              <span className="text-sm text-green-600 font-medium">Last 7 Days +5%</span>
            </div>
            <div className="h-32">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={weeklyTrend}>
                  <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: "#6B7280" }} />
                  <YAxis hide />
                  <Line type="monotone" dataKey="mood" stroke="#8B5CF6" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Stress Levels */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Stress Levels</h3>
              <TrendingDown className="w-5 h-5 text-green-600" />
            </div>
            <div className="flex items-baseline space-x-2 mb-4">
              <span className="text-3xl font-bold text-gray-900">-3%</span>
              <span className="text-sm text-green-600 font-medium">Last 7 Days -3%</span>
            </div>
            <div className="h-32">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stressData}>
                  <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: "#6B7280" }} />
                  <YAxis hide />
                  <Bar dataKey="level" fill="#E5E7EB" radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Tips for Brain Wellness */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Tips for Brain Wellness</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Mindfulness Meditation */}
            <div className="bg-gradient-to-br from-orange-100 to-orange-200 rounded-2xl p-6">
              <div className="bg-white rounded-lg p-4 mb-4 w-fit">
                <div className="w-16 h-20 bg-orange-50 rounded flex items-center justify-center">
                  <div className="w-8 h-8 bg-orange-200 rounded-full"></div>
                </div>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Mindfulness Meditation</h3>
              <p className="text-sm text-gray-600">Practice mindfulness to reduce stress and improve focus.</p>
            </div>

            {/* Nutritional Balance */}
            <div className="bg-gradient-to-br from-green-100 to-green-200 rounded-2xl p-6">
              <div className="bg-white rounded-lg p-4 mb-4 w-fit">
                <div className="w-16 h-20 bg-green-50 rounded flex items-center justify-center">
                  <div className="w-8 h-8 bg-green-200 rounded-full"></div>
                </div>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Nutritional Balance</h3>
              <p className="text-sm text-gray-600">Fuel your brain with a balanced diet rich in nutrients.</p>
            </div>

            {/* Regular Physical Activity */}
            <div className="bg-gradient-to-br from-orange-200 to-orange-300 rounded-2xl p-6">
              <div className="bg-white rounded-lg p-4 mb-4 w-fit">
                <div className="w-16 h-20 bg-orange-50 rounded flex items-center justify-center">
                  <div className="w-8 h-8 bg-orange-300 rounded-full"></div>
                </div>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Regular Physical Activity</h3>
              <p className="text-sm text-gray-600">Engage in regular physical activity to boost cognitive function.</p>
            </div>
          </div>
        </div>

        {/* Monthly Overview */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Monthly Mood Overview</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyData}>
                <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: "#6B7280" }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: "#6B7280" }} />
                <Bar dataKey="happy" stackId="a" fill="#FCD34D" />
                <Bar dataKey="calm" stackId="a" fill="#34D399" />
                <Bar dataKey="neutral" stackId="a" fill="#9CA3AF" />
                <Bar dataKey="anxious" stackId="a" fill="#FB923C" />
                <Bar dataKey="sad" stackId="a" fill="#60A5FA" />
                <Bar dataKey="stressed" stackId="a" fill="#F87171" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  )
}
