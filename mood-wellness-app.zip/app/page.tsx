"use client"

import { useEffect, useState } from "react"
import { Play } from "lucide-react"
import Link from "next/link"
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer } from "recharts"

const weeklyMoodData = [
  { day: "Mon", mood: 6.5 },
  { day: "Tue", mood: 7.2 },
  { day: "Wed", mood: 6.8 },
  { day: "Thu", mood: 7.5 },
  { day: "Fri", mood: 8.1 },
  { day: "Sat", mood: 8.5 },
  { day: "Sun", mood: 7.8 },
]

export default function HomePage() {
  const [currentMood, setCurrentMood] = useState<string | null>(null)
  const [userName] = useState("Sarah")

  useEffect(() => {
    const mood = localStorage.getItem("currentMood")
    setCurrentMood(mood)
  }, [])

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Welcome Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome back, {userName}</h1>
        </div>

        {/* Mood Tracking Section */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Mood Tracking</h2>

          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <div className="mb-6">
              <p className="text-sm text-gray-600 mb-2">Mood Over Time</p>
              <div className="flex items-baseline space-x-2">
                <span className="text-3xl font-bold text-gray-900">Average: 7.5</span>
                <span className="text-sm text-green-600 font-medium">Last 7 Days +2%</span>
              </div>
            </div>

            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={weeklyMoodData}>
                  <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: "#6B7280" }} />
                  <YAxis hide />
                  <Line type="monotone" dataKey="mood" stroke="#8B5CF6" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Quick Actions</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Journal Entries */}
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Journal Entries</h3>
                  <p className="text-sm text-gray-600 mb-4">Reflect on your thoughts and feelings</p>
                  <Link
                    href="/services"
                    className="inline-flex items-center text-sm font-medium text-gray-900 hover:text-purple-600 transition-colors"
                  >
                    View
                  </Link>
                </div>
                <div className="w-20 h-16 bg-gradient-to-br from-orange-100 to-orange-200 rounded-lg flex items-center justify-center">
                  <div className="w-8 h-10 bg-white rounded shadow-sm"></div>
                </div>
              </div>
            </div>

            {/* Recommended Videos */}
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Recommended Videos</h3>
                  <p className="text-sm text-gray-600 mb-4">Based on your mood, explore helpful content</p>
                  <Link
                    href="/resources"
                    className="inline-flex items-center text-sm font-medium text-gray-900 hover:text-purple-600 transition-colors"
                  >
                    Watch
                  </Link>
                </div>
                <div className="w-20 h-16 bg-gradient-to-br from-slate-600 to-slate-800 rounded-lg flex items-center justify-center">
                  <Play className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>

            {/* Daily Reflection */}
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Daily Reflection</h3>
                  <p className="text-sm text-purple-600 mb-4">What are you grateful for today?</p>
                  <button className="inline-flex items-center text-sm font-medium text-gray-900 hover:text-purple-600 transition-colors">
                    Reflect
                  </button>
                </div>
                <div className="w-20 h-16 bg-gradient-to-br from-orange-200 to-orange-300 rounded-lg flex items-center justify-center">
                  <div className="w-6 h-6 bg-white rounded-full"></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Mood Check-in */}
        <div className="mb-8">
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">How are you feeling today?</h3>
            <div className="flex flex-wrap gap-3 mb-4">
              {["Happy", "Calm", "Neutral", "Anxious", "Stressed"].map((mood) => (
                <button
                  key={mood}
                  onClick={() => {
                    setCurrentMood(mood.toLowerCase())
                    localStorage.setItem("currentMood", mood.toLowerCase())
                    localStorage.setItem("moodTimestamp", new Date().toISOString())
                  }}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    currentMood === mood.toLowerCase()
                      ? "bg-purple-100 text-purple-700 border border-purple-200"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  {mood}
                </button>
              ))}
            </div>
            {currentMood && (
              <Link
                href="/resources"
                className="inline-flex items-center px-4 py-2 bg-purple-600 text-white text-sm font-medium rounded-lg hover:bg-purple-700 transition-colors"
              >
                Get Personalized Content
              </Link>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
