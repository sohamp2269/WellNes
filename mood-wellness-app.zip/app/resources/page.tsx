"use client"

import { useEffect, useState } from "react"
import { Play, BookOpen, Heart, Zap, ExternalLink } from "lucide-react"
import Image from "next/image"

// Helper function to extract YouTube video ID from URL
const getYouTubeVideoId = (url: string) => {
  const match = url.match(
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/v\/|youtube\.com\/playlist\?list=)([^&\n?#]+)/,
  )
  return match ? match[1] : null
}

// Helper function to get YouTube thumbnail
const getYouTubeThumbnail = (url: string) => {
  const videoId = getYouTubeVideoId(url)
  return videoId ? `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg` : "/placeholder.svg?height=200&width=300"
}

const activities = [
  {
    id: 1,
    title: "Mindful Meditation",
    description: "A guided meditation to calm your mind.",
    color: "from-green-100 to-green-200",
    icon: "🧘‍♀️",
  },
  {
    id: 2,
    title: "Yoga Flow",
    description: "A gentle yoga flow to release tension.",
    color: "from-orange-100 to-orange-200",
    icon: "🧘‍♀️",
  },
  {
    id: 3,
    title: "Gratitude Journaling",
    description: "Reflect on the things you're grateful for.",
    color: "from-amber-100 to-amber-200",
    icon: "📝",
  },
  {
    id: 4,
    title: "Healing Flow: Yoga for Sadness Relief",
    description: "A 20-30 minute yoga plan with specific poses for emotional healing.",
    color: "from-pink-100 to-pink-200",
    icon: "🧘‍♀️",
  },
]

const videos = [
  {
    id: 1,
    title: "Understanding Your Mood",
    description: "Learn about the science behind your emotions.",
    url: "https://www.youtube.com/watch?v=ZbZSe6N_BXs",
    thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=ZbZSe6N_BXs"),
    color: "from-teal-500 to-teal-700",
  },
  {
    id: 2,
    title: "Stress Management Techniques",
    description: "Practical tips to manage stress.",
    url: "https://www.youtube.com/watch?v=UPkMkIOzej8",
    thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=UPkMkIOzej8"),
    color: "from-gray-800 to-black",
  },
  {
    id: 3,
    title: "Improving Your Sleep",
    description: "Strategies for a better night's sleep.",
    url: "https://www.youtube.com/watch?v=kVi8ICWu3WI",
    thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=kVi8ICWu3WI"),
    color: "from-blue-100 to-blue-200",
  },
]

const resources = {
  happy: {
    videos: [
      {
        id: 1,
        title: "Pharrell Williams - Happy",
        duration: "4:00",
        url: "https://www.youtube.com/watch?v=ZbZSe6N_BXs",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=ZbZSe6N_BXs"),
        category: "Music",
      },
      {
        id: 2,
        title: "Mood Booster Best Songs You Will Feel Happy",
        duration: "1:30:00",
        url: "https://www.youtube.com/watch?v=UPkMkIOzej8",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=UPkMkIOzej8"),
        category: "Playlist",
      },
      {
        id: 3,
        title: "Uplifting and Upbeat Music to Get You in a Good Mood",
        duration: "45:00",
        url: "https://www.youtube.com/watch?v=kVi8ICWu3WI",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=kVi8ICWu3WI"),
        category: "Music",
      },
      {
        id: 4,
        title: "Happy Day Relaxing & Chill House Mix",
        duration: "2:00:00",
        url: "https://www.youtube.com/watch?v=321bN6VCJQ4",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=321bN6VCJQ4"),
        category: "Mix",
      },
      {
        id: 5,
        title: "Happy Mood Music - Start Every Day With A Smile",
        duration: "1:15:00",
        url: "https://www.youtube.com/watch?v=v9F3TSkOGDE",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=v9F3TSkOGDE"),
        category: "Motivation",
      },
    ],
    journals: [
      { id: 1, title: "Celebrating Small Wins", prompt: "What made you smile today?", category: "Gratitude" },
      { id: 2, title: "Future Dreams", prompt: "Describe your ideal day in detail", category: "Visualization" },
      { id: 3, title: "Joy Moments", prompt: "List 5 things that bring you pure joy", category: "Reflection" },
    ],
    yoga: [
      {
        id: 1,
        title: "Sun Salutation Flow",
        duration: "25 min",
        level: "Beginner",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 2,
        title: "Heart Opening Sequence",
        duration: "30 min",
        level: "Intermediate",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 3,
        title: "Energizing Vinyasa",
        duration: "45 min",
        level: "Advanced",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
    ],
    meditation: [
      {
        id: 1,
        title: "Guided Meditation for Happiness",
        duration: "10 min",
        url: "https://www.youtube.com/watch?v=6n_0MLZVAbQ",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=6n_0MLZVAbQ"),
        type: "Guided",
      },
      {
        id: 2,
        title: "Joy and Positivity Meditation",
        duration: "15 min",
        url: "https://www.youtube.com/watch?v=rJ56DPoGP38",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=rJ56DPoGP38"),
        type: "Visualization",
      },
      {
        id: 3,
        title: "Morning Happiness Meditation",
        duration: "12 min",
        url: "https://www.youtube.com/watch?v=PR21ngMPDLE",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=PR21ngMPDLE"),
        type: "Morning",
      },
      {
        id: 4,
        title: "Gratitude and Joy Practice",
        duration: "8 min",
        url: "https://www.youtube.com/watch?v=Y1hy5f69CRE",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=Y1hy5f69CRE"),
        type: "Gratitude",
      },
      {
        id: 5,
        title: "Uplifting Energy Meditation",
        duration: "20 min",
        url: "https://www.youtube.com/watch?v=inpok4MKVLM",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=inpok4MKVLM"),
        type: "Energy",
      },
    ],
  },
  sad: {
    videos: [
      {
        id: 6,
        title: "Sam Cooke - Sad Mood",
        duration: "3:30",
        url: "https://www.youtube.com/watch?v=J6iZmcgpHGU",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=J6iZmcgpHGU"),
        category: "Music",
      },
      {
        id: 7,
        title: "Lauren Spencer Smith - Sad Forever",
        duration: "3:45",
        url: "https://www.youtube.com/watch?v=L1yolHyHtuw",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=L1yolHyHtuw"),
        category: "Music",
      },
      {
        id: 8,
        title: "Sam Cooke - Another Sad Mood",
        duration: "3:20",
        url: "https://www.youtube.com/watch?v=OZ6xyMaVsRo",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=OZ6xyMaVsRo"),
        category: "Music",
      },
      {
        id: 9,
        title: "Sam Cooke - Sad Mood (Another Version)",
        duration: "3:15",
        url: "https://www.youtube.com/watch?v=9fWLYCRLsUU",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=9fWLYCRLsUU"),
        category: "Music",
      },
      {
        id: 10,
        title: "Sam Cooke - Sad Mood with Lyrics",
        duration: "3:30",
        url: "https://www.youtube.com/watch?v=TVwta80oUQ4",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=TVwta80oUQ4"),
        category: "Music",
      },
    ],
    journals: [
      {
        id: 4,
        title: "Emotional Processing",
        prompt: "What emotions are you experiencing right now?",
        category: "Processing",
      },
      { id: 5, title: "Self-Compassion Letter", prompt: "Write a kind letter to yourself", category: "Self-Care" },
      { id: 6, title: "Hope and Healing", prompt: "What gives you hope for tomorrow?", category: "Hope" },
    ],
    yoga: [
      {
        id: 4,
        title: "Heart Opening for Healing",
        duration: "28 min",
        level: "Beginner",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 5,
        title: "Gentle Flow for Low Energy",
        duration: "20 min",
        level: "All Levels",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 6,
        title: "Restorative Backbends",
        duration: "35 min",
        level: "All Levels",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
    ],
    meditation: [
      {
        id: 6,
        title: "Healing Meditation for Sadness",
        duration: "15 min",
        url: "https://www.youtube.com/watch?v=HM7oTRPwtUQ",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=HM7oTRPwtUQ"),
        type: "Healing",
      },
      {
        id: 7,
        title: "Self-Compassion Meditation",
        duration: "20 min",
        url: "https://www.youtube.com/watch?v=ug26l-2ktxA",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=ug26l-2ktxA"),
        type: "Self-Compassion",
      },
      {
        id: 8,
        title: "Emotional Release Meditation",
        duration: "18 min",
        url: "https://www.youtube.com/watch?v=H7rJKxGGp_s",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=H7rJKxGGp_s"),
        type: "Release",
      },
      {
        id: 9,
        title: "Comfort and Peace Meditation",
        duration: "12 min",
        url: "https://www.youtube.com/watch?v=xRxT9cOKiM8",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=xRxT9cOKiM8"),
        type: "Comfort",
      },
      {
        id: 10,
        title: "Inner Strength Meditation",
        duration: "25 min",
        url: "https://www.youtube.com/watch?v=FvCqKUKa-0U",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=FvCqKUKa-0U"),
        type: "Strength",
      },
    ],
  },
  neutral: {
    videos: [
      {
        id: 11,
        title: "Mood: Neutral Ambient Playlist",
        duration: "2:00:00",
        url: "https://www.youtube.com/playlist?list=PL-F7saF_vW0dl-CrUgs6CG3DDjr4EX_ee",
        thumbnail: "/placeholder.svg?height=200&width=300",
        category: "Ambient",
      },
      {
        id: 12,
        title: "Neutral to Light Positive Music for Study/Work",
        duration: "1:30:00",
        url: "https://www.youtube.com/watch?v=WpZ1WiqCf94",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=WpZ1WiqCf94"),
        category: "Study",
      },
      {
        id: 13,
        title: "Neutrality: Ambient Sci Fi Music",
        duration: "45:00",
        url: "https://www.youtube.com/watch?v=cT4fU7BZV9I",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=cT4fU7BZV9I"),
        category: "Sci-Fi",
      },
      {
        id: 14,
        title: "Corporate Ambient / Royalty Free Music",
        duration: "30:00",
        url: "https://www.youtube.com/watch?v=XE_00u9M9jU",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=XE_00u9M9jU"),
        category: "Corporate",
      },
      {
        id: 15,
        title: "Ambient - Quiet Music, Power, Energy & Lounge",
        duration: "1:00:00",
        url: "https://www.youtube.com/watch?v=P0ynIxoM3hE",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=P0ynIxoM3hE"),
        category: "Lounge",
      },
    ],
    journals: [
      { id: 7, title: "Daily Reflection", prompt: "How did today go for you?", category: "Reflection" },
      { id: 8, title: "Goal Setting", prompt: "What would you like to focus on this week?", category: "Planning" },
      { id: 9, title: "Mindful Check-in", prompt: "What do you need right now?", category: "Self-Awareness" },
    ],
    yoga: [
      {
        id: 7,
        title: "Balanced Hatha Practice",
        duration: "35 min",
        level: "Intermediate",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 8,
        title: "All-Around Flow",
        duration: "40 min",
        level: "All Levels",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 9,
        title: "Foundation Building",
        duration: "30 min",
        level: "Beginner",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
    ],
    meditation: [
      {
        id: 11,
        title: "Mindfulness Meditation",
        duration: "15 min",
        url: "https://www.youtube.com/watch?v=UNvUL99Pk04",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=UNvUL99Pk04"),
        type: "Mindfulness",
      },
      {
        id: 12,
        title: "Present Moment Awareness",
        duration: "12 min",
        url: "https://www.youtube.com/watch?v=uixvMi39MQU",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=uixvMi39MQU"),
        type: "Awareness",
      },
      {
        id: 13,
        title: "Balanced Energy Meditation",
        duration: "18 min",
        url: "https://www.youtube.com/watch?v=agw9nh_49d0",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=agw9nh_49d0"),
        type: "Balance",
      },
      {
        id: 14,
        title: "Centered Focus Meditation",
        duration: "20 min",
        url: "https://www.youtube.com/watch?v=OqKH0qVP8IU",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=OqKH0qVP8IU"),
        type: "Focus",
      },
      {
        id: 15,
        title: "Calm Stability Practice",
        duration: "16 min",
        url: "https://www.youtube.com/watch?v=inpok4MKVLM",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=inpok4MKVLM"),
        type: "Stability",
      },
    ],
  },
  anxious: {
    videos: [
      {
        id: 24,
        title: "Anxiety Relief Techniques",
        duration: "18 min",
        thumbnail: "/placeholder.svg?height=200&width=300",
        category: "Mental Health",
      },
      {
        id: 25,
        title: "Grounding Exercises",
        duration: "15 min",
        thumbnail: "/placeholder.svg?height=200&width=300",
        category: "Coping",
      },
      {
        id: 26,
        title: "Progressive Muscle Relaxation",
        duration: "22 min",
        thumbnail: "/placeholder.svg?height=200&width=300",
        category: "Relaxation",
      },
    ],
    journals: [
      { id: 16, title: "Worry Release", prompt: "What worries can you let go of today?", category: "Release" },
      {
        id: 17,
        title: "Strength Inventory",
        prompt: "List your personal strengths and past victories",
        category: "Empowerment",
      },
      { id: 18, title: "Safe Space", prompt: "Describe your ideal safe and peaceful place", category: "Visualization" },
    ],
    yoga: [
      {
        id: 16,
        title: "Calming Yoga for Anxiety",
        duration: "30 min",
        level: "Beginner",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 17,
        title: "Grounding Flow",
        duration: "25 min",
        level: "All Levels",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 18,
        title: "Nervous System Reset",
        duration: "35 min",
        level: "Intermediate",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
    ],
    meditation: [
      {
        id: 24,
        title: "Anxiety Relief Meditation",
        duration: "15 min",
        type: "Guided",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 25,
        title: "4-7-8 Breathing",
        duration: "8 min",
        type: "Breathwork",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 26,
        title: "Safe Harbor Visualization",
        duration: "20 min",
        type: "Visualization",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
    ],
  },
  stressed: {
    videos: [
      {
        id: 27,
        title: "Quick Stress Relief",
        duration: "8 min",
        thumbnail: "/placeholder.svg?height=200&width=300",
        category: "Quick Fix",
      },
      {
        id: 28,
        title: "Desk Yoga for Work Stress",
        duration: "12 min",
        thumbnail: "/placeholder.svg?height=200&width=300",
        category: "Workplace",
      },
      {
        id: 29,
        title: "Evening Wind Down",
        duration: "25 min",
        thumbnail: "/placeholder.svg?height=200&width=300",
        category: "Relaxation",
      },
    ],
    journals: [
      { id: 19, title: "Stress Inventory", prompt: "What's causing you stress right now?", category: "Awareness" },
      { id: 20, title: "Priority Reset", prompt: "What truly matters most to you?", category: "Clarity" },
      { id: 21, title: "Stress Solutions", prompt: "What's one small step you can take today?", category: "Action" },
    ],
    yoga: [
      {
        id: 19,
        title: "Stress Relief Flow",
        duration: "22 min",
        level: "Beginner",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 20,
        title: "Tension Release Sequence",
        duration: "18 min",
        level: "All Levels",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 21,
        title: "Calming Bedtime Yoga",
        duration: "30 min",
        level: "Beginner",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
    ],
    meditation: [
      {
        id: 27,
        title: "Stress Reduction Meditation",
        duration: "12 min",
        type: "Guided",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 28,
        title: "Mountain Meditation",
        duration: "15 min",
        type: "Visualization",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 29,
        title: "Release and Let Go",
        duration: "20 min",
        type: "Release",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
    ],
  },
  emotional: {
    videos: [
      {
        id: 16,
        title: "Most Emotional Music Ever: 'Nightsky'",
        duration: "5:30",
        url: "https://www.youtube.com/watch?v=8DSeZji2x-Y",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=8DSeZji2x-Y"),
        category: "Emotional",
      },
      {
        id: 17,
        title: "So Emotional! TRY NOT TO CRY",
        duration: "10:00",
        url: "https://www.youtube.com/watch?v=UIVMJMvdBO4",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=UIVMJMvdBO4"),
        category: "Emotional",
      },
      {
        id: 18,
        title: "Carl Thomas - Emotional (Official Music Video)",
        duration: "4:15",
        url: "https://www.youtube.com/watch?v=CW0gaTRzzlc",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=CW0gaTRzzlc"),
        category: "Music",
      },
      {
        id: 19,
        title: "Ashe - Emotional (Official Music Video)",
        duration: "3:45",
        url: "https://www.youtube.com/watch?v=8Jy9nI2xmQ8",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=8Jy9nI2xmQ8"),
        category: "Music",
      },
      {
        id: 20,
        title: "Johnny Cash - Hurt",
        duration: "3:58",
        url: "https://www.youtube.com/watch?v=vt1Pwfnh5pc",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=vt1Pwfnh5pc"),
        category: "Music",
      },
    ],
    journals: [
      { id: 10, title: "Emotional Release", prompt: "What emotions need to be expressed today?", category: "Release" },
      {
        id: 11,
        title: "Deep Feelings",
        prompt: "Explore what you're feeling without judgment",
        category: "Exploration",
      },
      { id: 12, title: "Emotional Wisdom", prompt: "What are your emotions trying to tell you?", category: "Insight" },
    ],
    yoga: [
      {
        id: 10,
        title: "Emotional Release Flow",
        duration: "35 min",
        level: "Intermediate",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 11,
        title: "Heart Opening Practice",
        duration: "40 min",
        level: "All Levels",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 12,
        title: "Gentle Emotional Healing",
        duration: "30 min",
        level: "Beginner",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
    ],
    meditation: [
      {
        id: 16,
        title: "Emotional Processing Meditation",
        duration: "20 min",
        url: "https://www.youtube.com/watch?v=fXg-8LqpJwI",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=fXg-8LqpJwI"),
        type: "Processing",
      },
      {
        id: 17,
        title: "Deep Emotional Healing",
        duration: "25 min",
        url: "https://www.youtube.com/watch?v=149tYQEhqvY",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=149tYQEhqvY"),
        type: "Healing",
      },
      {
        id: 18,
        title: "Emotional Balance Live Session",
        duration: "60 min",
        url: "https://www.youtube.com/live/V7Wy9t2mTOE",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/live/V7Wy9t2mTOE"),
        type: "Live",
      },
      {
        id: 19,
        title: "Heart Centered Meditation",
        duration: "18 min",
        url: "https://www.youtube.com/watch?v=WGH8f3YkGBQ",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=WGH8f3YkGBQ"),
        type: "Heart",
      },
      {
        id: 20,
        title: "Emotional Clarity Practice",
        duration: "22 min",
        url: "https://www.youtube.com/watch?v=jfKfPfyJRdk",
        thumbnail: getYouTubeThumbnail("https://www.youtube.com/watch?v=jfKfPfyJRdk"),
        type: "Clarity",
      },
    ],
  },
  // Keep existing moods for backward compatibility
  calm: {
    videos: [
      {
        id: 21,
        title: "Gentle Stretching",
        duration: "20 min",
        thumbnail: "/placeholder.svg?height=200&width=300",
        category: "Wellness",
      },
      {
        id: 22,
        title: "Nature Sounds Relaxation",
        duration: "30 min",
        thumbnail: "/placeholder.svg?height=200&width=300",
        category: "Relaxation",
      },
      {
        id: 23,
        title: "Breathing Techniques",
        duration: "12 min",
        thumbnail: "/placeholder.svg?height=200&width=300",
        category: "Breathwork",
      },
    ],
    journals: [
      {
        id: 13,
        title: "Peaceful Moments",
        prompt: "Describe a moment when you felt completely at peace",
        category: "Reflection",
      },
      {
        id: 14,
        title: "Mindful Observations",
        prompt: "What do you notice in this present moment?",
        category: "Mindfulness",
      },
      {
        id: 15,
        title: "Gratitude Practice",
        prompt: "Write about something you're grateful for today",
        category: "Gratitude",
      },
    ],
    yoga: [
      {
        id: 13,
        title: "Restorative Yoga",
        duration: "40 min",
        level: "All Levels",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 14,
        title: "Gentle Hatha Flow",
        duration: "35 min",
        level: "Beginner",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 15,
        title: "Yin Yoga for Relaxation",
        duration: "50 min",
        level: "All Levels",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
    ],
    meditation: [
      {
        id: 21,
        title: "Body Scan Meditation",
        duration: "20 min",
        type: "Guided",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 22,
        title: "Peaceful Lake Visualization",
        duration: "18 min",
        type: "Visualization",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 23,
        title: "Mindful Breathing",
        duration: "10 min",
        type: "Breathwork",
        thumbnail: "/placeholder.svg?height=200&width=300",
      },
    ],
  },
}

export default function ResourcesPage() {
  const [currentMood, setCurrentMood] = useState<string>("neutral")

  useEffect(() => {
    const mood = localStorage.getItem("currentMood") || "neutral"
    setCurrentMood(mood)
  }, [])

  const handleVideoClick = (url: string) => {
    window.open(url, "_blank", "noopener,noreferrer")
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Your Daily Plan</h1>
          <p className="text-gray-600">Based on your mood check-in, here's a plan to help you feel your best.</p>
        </div>

        {/* Activities Section */}
        <div className="mb-12">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Activities</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {activities.map((activity) => (
              <div key={activity.id} className={`bg-gradient-to-br ${activity.color} rounded-2xl p-6`}>
                <div className="text-4xl mb-4">{activity.icon}</div>
                <h3 className="font-semibold text-gray-900 mb-2">{activity.title}</h3>
                <p className="text-sm text-gray-600">{activity.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Videos Section */}
        <div className="mb-12">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Videos</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {videos.map((video) => (
              <div
                key={video.id}
                className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => handleVideoClick(video.url)}
              >
                <div className={`bg-gradient-to-br ${video.color} h-48 flex items-center justify-center relative`}>
                  <Image
                    src={video.thumbnail || "/placeholder.svg"}
                    alt={video.title}
                    width={300}
                    height={200}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                    <div className="flex items-center space-x-2 text-white">
                      <Play className="w-12 h-12" />
                      <ExternalLink className="w-6 h-6" />
                    </div>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="font-semibold text-gray-900 mb-2">{video.title}</h3>
                  <p className="text-sm text-gray-600">{video.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Tomorrow's Plan */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Tomorrow's Plan</h2>
          <textarea
            placeholder="Write down your plan for tomorrow..."
            className="w-full h-32 p-4 border border-gray-200 rounded-lg resize-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          />
        </div>

        {/* Mood Resources Section */}
        <div className="mt-12">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Resources for Your Mood</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {resources[currentMood].videos.map((video) => (
              <div
                key={video.id}
                className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => handleVideoClick(video.url)}
              >
                <div className="relative">
                  <Image
                    src={video.thumbnail || "/placeholder.svg"}
                    alt={video.title}
                    width={300}
                    height={200}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                    <div className="flex items-center space-x-2 text-white">
                      <Play className="w-12 h-12" />
                      {video.url && <ExternalLink className="w-6 h-6" />}
                    </div>
                  </div>
                  <div className="absolute top-2 right-2 bg-black bg-opacity-70 text-white px-2 py-1 rounded text-sm">
                    {video.duration}
                  </div>
                </div>
                <div className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium text-gray-600 bg-gray-50`}>
                      {video.category}
                    </span>
                    {video.url && <ExternalLink className="w-4 h-4 text-gray-400" />}
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{video.title}</h3>
                  <button
                    className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-2 px-4 rounded-lg font-medium hover:from-purple-700 hover:to-pink-700 transition-colors"
                    onClick={(e) => {
                      e.stopPropagation()
                      handleVideoClick(video.url)
                    }}
                  >
                    {video.url ? "Watch on YouTube" : "Start Session"}
                  </button>
                </div>
              </div>
            ))}
            {resources[currentMood].journals.map((journal) => (
              <div key={journal.id} className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow">
                <div className="flex items-center justify-between mb-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium text-gray-600 bg-gray-50`}>
                    {journal.category}
                  </span>
                  <BookOpen className="w-5 h-5 text-gray-400" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">{journal.title}</h3>
                <p className="text-gray-600 text-sm mb-4">{journal.prompt}</p>
                <button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-2 px-4 rounded-lg font-medium hover:from-purple-700 hover:to-pink-700 transition-colors">
                  Start Writing
                </button>
              </div>
            ))}
            {resources[currentMood].yoga.map((yoga) => (
              <div key={yoga.id} className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow">
                <div className="flex items-center justify-between mb-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium text-gray-600 bg-gray-50`}>
                    {yoga.level}
                  </span>
                  <Heart className="w-5 h-5 text-gray-400" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">{yoga.title}</h3>
                <p className="text-gray-600 text-sm mb-4">{yoga.duration}</p>
                <button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-2 px-4 rounded-lg font-medium hover:from-purple-700 hover:to-pink-700 transition-colors">
                  Start Session
                </button>
              </div>
            ))}
            {resources[currentMood].meditation.map((meditation) => (
              <div key={meditation.id} className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow">
                <div className="flex items-center justify-between mb-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium text-gray-600 bg-gray-50`}>
                    {meditation.type}
                  </span>
                  <Zap className="w-5 h-5 text-gray-400" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">{meditation.title}</h3>
                <p className="text-gray-600 text-sm mb-4">{meditation.duration}</p>
                <button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-2 px-4 rounded-lg font-medium hover:from-purple-700 hover:to-pink-700 transition-colors">
                  Start Session
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
